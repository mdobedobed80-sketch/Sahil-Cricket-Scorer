# Sahil Cricket Scorer — Android Project

Phone se APK banane ke liye GitHub par is project ko upload karein.

1. GitHub me new repository banayein.
2. Is ZIP ke andar ki files upload karein (poora `sahil_native` folder nahi, uske andar ki files).
3. Repository me **Actions** tab kholen.
4. **Build Sahil Cricket Scorer APK** workflow select karein.
5. **Run workflow** dabayein.
6. Build complete hone ke baad workflow run ke **Artifacts** section se `Sahil-Cricket-Scorer-APK` download karein.

App: Sahil Cricket Scorer
Package: com.sahil.cricketscorer
